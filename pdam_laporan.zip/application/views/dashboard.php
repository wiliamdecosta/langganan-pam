<h3 class="page-title">Home</h3>
<div class="alert alert-default" role="alert">
    <strong class="green">Welcome to Sistem Informasi Gereja HKBP</strong>
</div>