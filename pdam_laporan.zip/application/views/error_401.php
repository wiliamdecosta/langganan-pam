<link href="<?php echo base_url(); ?>assets/pages/css/error.min.css" rel="stylesheet" type="text/css" />

<div class="row">
    <div class="col-md-12 page-404">
        <div class="number font-red"> 401 </div>
        <div class="details">
            <h3>Oops! Unauthorized Access</h3>
            <p> We're sorry. You don't have permission to access this page.
                <br/>
                <a href="<?php echo base_url(); ?>"> Return home </a> </p>
        </div>
    </div>
</div>
