<!-- jqgrid -->
<link href="<?php echo base_url(); ?>assets/jqgrid/css/ui.jqgrid-bootstrap.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/css/jqgrid.custom.css" rel="stylesheet" type="text/css"/>

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootgrid/jquery.bootgrid.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootgrid.custom.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/node_modules/sweetalert/sweetalert.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/simplePagination.css"/>

