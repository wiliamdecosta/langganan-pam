<!-- breadcrumb -->
<div class="page-bar">
    <?php echo breadCrumbs($this->input->post('menu_id')); ?>
</div>
<!-- end breadcrumb -->