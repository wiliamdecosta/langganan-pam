<link href="<?php echo base_url(); ?>assets/pages/css/error.min.css" rel="stylesheet" type="text/css" />

<div class="row">
    <div class="col-md-12 page-404">
        <div class="number font-red"> 404 </div>
        <div class="details">
            <h3>Oops! You're lost.</h3>
            <p> We can not find the page you're looking for.
        </div>
    </div>
</div>
