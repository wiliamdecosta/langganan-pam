<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-03 06:09:04 --> Config Class Initialized
INFO - 2016-05-03 06:09:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:09:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:09:04 --> Utf8 Class Initialized
INFO - 2016-05-03 06:09:04 --> URI Class Initialized
DEBUG - 2016-05-03 06:09:04 --> No URI present. Default controller set.
INFO - 2016-05-03 06:09:04 --> Router Class Initialized
INFO - 2016-05-03 06:09:04 --> Output Class Initialized
INFO - 2016-05-03 06:09:04 --> Security Class Initialized
DEBUG - 2016-05-03 06:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:09:04 --> CSRF cookie sent
INFO - 2016-05-03 06:09:04 --> Input Class Initialized
INFO - 2016-05-03 06:09:04 --> Language Class Initialized
INFO - 2016-05-03 06:09:04 --> Loader Class Initialized
INFO - 2016-05-03 06:09:04 --> Helper loaded: url_helper
INFO - 2016-05-03 06:09:04 --> Database Driver Class Initialized
INFO - 2016-05-03 06:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:09:05 --> Controller Class Initialized
DEBUG - 2016-05-03 06:09:05 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:09:05 --> Email Class Initialized
INFO - 2016-05-03 06:09:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:09:05 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:09:05 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:09:05 --> Model Class Initialized
INFO - 2016-05-03 06:09:05 --> Helper loaded: date_helper
INFO - 2016-05-03 06:09:05 --> Helper loaded: form_helper
INFO - 2016-05-03 06:09:05 --> Form Validation Class Initialized
INFO - 2016-05-03 06:09:05 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:09:05 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:09:05 --> Final output sent to browser
DEBUG - 2016-05-03 06:09:05 --> Total execution time: 1.1615
INFO - 2016-05-03 06:09:17 --> Config Class Initialized
INFO - 2016-05-03 06:09:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:09:17 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:09:17 --> Utf8 Class Initialized
INFO - 2016-05-03 06:09:17 --> URI Class Initialized
DEBUG - 2016-05-03 06:09:17 --> No URI present. Default controller set.
INFO - 2016-05-03 06:09:17 --> Router Class Initialized
INFO - 2016-05-03 06:09:17 --> Output Class Initialized
INFO - 2016-05-03 06:09:17 --> Security Class Initialized
DEBUG - 2016-05-03 06:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:09:17 --> CSRF cookie sent
INFO - 2016-05-03 06:09:17 --> Input Class Initialized
INFO - 2016-05-03 06:09:17 --> Language Class Initialized
INFO - 2016-05-03 06:09:17 --> Loader Class Initialized
INFO - 2016-05-03 06:09:17 --> Helper loaded: url_helper
INFO - 2016-05-03 06:09:17 --> Database Driver Class Initialized
INFO - 2016-05-03 06:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:09:17 --> Controller Class Initialized
DEBUG - 2016-05-03 06:09:17 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:09:17 --> Email Class Initialized
INFO - 2016-05-03 06:09:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:09:17 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:09:17 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:09:17 --> Model Class Initialized
INFO - 2016-05-03 06:09:17 --> Helper loaded: date_helper
INFO - 2016-05-03 06:09:17 --> Helper loaded: form_helper
INFO - 2016-05-03 06:09:17 --> Form Validation Class Initialized
INFO - 2016-05-03 06:09:17 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:09:17 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:09:17 --> Final output sent to browser
DEBUG - 2016-05-03 06:09:17 --> Total execution time: 0.3008
INFO - 2016-05-03 06:09:34 --> Config Class Initialized
INFO - 2016-05-03 06:09:34 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:09:34 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:09:34 --> Utf8 Class Initialized
INFO - 2016-05-03 06:09:34 --> URI Class Initialized
DEBUG - 2016-05-03 06:09:34 --> No URI present. Default controller set.
INFO - 2016-05-03 06:09:34 --> Router Class Initialized
INFO - 2016-05-03 06:09:34 --> Output Class Initialized
INFO - 2016-05-03 06:09:34 --> Security Class Initialized
DEBUG - 2016-05-03 06:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:09:34 --> CSRF cookie sent
INFO - 2016-05-03 06:09:34 --> Input Class Initialized
INFO - 2016-05-03 06:09:34 --> Language Class Initialized
INFO - 2016-05-03 06:09:34 --> Loader Class Initialized
INFO - 2016-05-03 06:09:34 --> Helper loaded: url_helper
INFO - 2016-05-03 06:09:34 --> Database Driver Class Initialized
INFO - 2016-05-03 06:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:09:34 --> Controller Class Initialized
DEBUG - 2016-05-03 06:09:34 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:09:34 --> Email Class Initialized
INFO - 2016-05-03 06:09:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:09:34 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:09:34 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:09:34 --> Model Class Initialized
INFO - 2016-05-03 06:09:34 --> Helper loaded: date_helper
INFO - 2016-05-03 06:09:34 --> Helper loaded: form_helper
INFO - 2016-05-03 06:09:34 --> Form Validation Class Initialized
INFO - 2016-05-03 06:09:34 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:09:34 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:09:34 --> Final output sent to browser
DEBUG - 2016-05-03 06:09:34 --> Total execution time: 0.5104
INFO - 2016-05-03 06:09:46 --> Config Class Initialized
INFO - 2016-05-03 06:09:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:09:46 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:09:46 --> Utf8 Class Initialized
INFO - 2016-05-03 06:09:46 --> Config Class Initialized
INFO - 2016-05-03 06:09:46 --> URI Class Initialized
INFO - 2016-05-03 06:09:46 --> Hooks Class Initialized
INFO - 2016-05-03 06:09:46 --> Router Class Initialized
DEBUG - 2016-05-03 06:09:46 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:09:46 --> Utf8 Class Initialized
INFO - 2016-05-03 06:09:46 --> Output Class Initialized
INFO - 2016-05-03 06:09:46 --> URI Class Initialized
INFO - 2016-05-03 06:09:46 --> Security Class Initialized
DEBUG - 2016-05-03 06:09:46 --> No URI present. Default controller set.
DEBUG - 2016-05-03 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:09:46 --> Router Class Initialized
INFO - 2016-05-03 06:09:46 --> Output Class Initialized
INFO - 2016-05-03 06:09:46 --> Security Class Initialized
DEBUG - 2016-05-03 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:09:46 --> CSRF cookie sent
INFO - 2016-05-03 06:09:46 --> CSRF token verified
INFO - 2016-05-03 06:09:46 --> Input Class Initialized
INFO - 2016-05-03 06:09:46 --> Language Class Initialized
INFO - 2016-05-03 06:09:46 --> Loader Class Initialized
INFO - 2016-05-03 06:09:46 --> Helper loaded: url_helper
INFO - 2016-05-03 06:09:46 --> Database Driver Class Initialized
INFO - 2016-05-03 06:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:09:46 --> Controller Class Initialized
DEBUG - 2016-05-03 06:09:46 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:09:46 --> Email Class Initialized
INFO - 2016-05-03 06:09:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:09:46 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:09:46 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:09:46 --> Model Class Initialized
INFO - 2016-05-03 06:09:46 --> Helper loaded: date_helper
INFO - 2016-05-03 06:09:46 --> Helper loaded: form_helper
INFO - 2016-05-03 06:09:46 --> Form Validation Class Initialized
INFO - 2016-05-03 06:09:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:09:46 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:09:46 --> Final output sent to browser
DEBUG - 2016-05-03 06:09:46 --> Total execution time: 0.3299
INFO - 2016-05-03 06:09:56 --> Config Class Initialized
INFO - 2016-05-03 06:09:56 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:09:56 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:09:56 --> Utf8 Class Initialized
INFO - 2016-05-03 06:09:56 --> URI Class Initialized
INFO - 2016-05-03 06:09:56 --> Router Class Initialized
INFO - 2016-05-03 06:09:56 --> Output Class Initialized
INFO - 2016-05-03 06:09:56 --> Security Class Initialized
DEBUG - 2016-05-03 06:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:11:25 --> Config Class Initialized
INFO - 2016-05-03 06:11:25 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:11:25 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:11:25 --> Utf8 Class Initialized
INFO - 2016-05-03 06:11:25 --> URI Class Initialized
DEBUG - 2016-05-03 06:11:25 --> No URI present. Default controller set.
INFO - 2016-05-03 06:11:25 --> Router Class Initialized
INFO - 2016-05-03 06:11:25 --> Output Class Initialized
INFO - 2016-05-03 06:11:25 --> Security Class Initialized
DEBUG - 2016-05-03 06:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:11:25 --> CSRF cookie sent
INFO - 2016-05-03 06:11:25 --> Input Class Initialized
INFO - 2016-05-03 06:11:25 --> Language Class Initialized
INFO - 2016-05-03 06:11:25 --> Loader Class Initialized
INFO - 2016-05-03 06:11:25 --> Helper loaded: url_helper
INFO - 2016-05-03 06:11:25 --> Database Driver Class Initialized
INFO - 2016-05-03 06:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:11:25 --> Controller Class Initialized
DEBUG - 2016-05-03 06:11:25 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:11:25 --> Email Class Initialized
INFO - 2016-05-03 06:11:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:11:25 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:11:25 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:11:25 --> Model Class Initialized
INFO - 2016-05-03 06:11:25 --> Helper loaded: date_helper
INFO - 2016-05-03 06:11:26 --> Helper loaded: form_helper
INFO - 2016-05-03 06:11:26 --> Form Validation Class Initialized
INFO - 2016-05-03 06:11:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:11:26 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:11:26 --> Final output sent to browser
DEBUG - 2016-05-03 06:11:26 --> Total execution time: 0.2448
INFO - 2016-05-03 06:12:10 --> Config Class Initialized
INFO - 2016-05-03 06:12:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:12:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:12:10 --> Utf8 Class Initialized
INFO - 2016-05-03 06:12:10 --> URI Class Initialized
DEBUG - 2016-05-03 06:12:10 --> No URI present. Default controller set.
INFO - 2016-05-03 06:12:10 --> Router Class Initialized
INFO - 2016-05-03 06:12:10 --> Output Class Initialized
INFO - 2016-05-03 06:12:10 --> Security Class Initialized
DEBUG - 2016-05-03 06:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:12:10 --> Input Class Initialized
INFO - 2016-05-03 06:12:10 --> Language Class Initialized
INFO - 2016-05-03 06:12:10 --> Loader Class Initialized
INFO - 2016-05-03 06:12:10 --> Helper loaded: url_helper
INFO - 2016-05-03 06:12:10 --> Database Driver Class Initialized
INFO - 2016-05-03 06:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:12:10 --> Controller Class Initialized
DEBUG - 2016-05-03 06:12:10 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:12:10 --> Email Class Initialized
INFO - 2016-05-03 06:12:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:12:10 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:12:10 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:12:10 --> Model Class Initialized
INFO - 2016-05-03 06:12:10 --> Helper loaded: date_helper
INFO - 2016-05-03 06:12:10 --> Helper loaded: form_helper
INFO - 2016-05-03 06:12:10 --> Form Validation Class Initialized
INFO - 2016-05-03 06:12:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:12:10 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:12:10 --> Final output sent to browser
DEBUG - 2016-05-03 06:12:10 --> Total execution time: 0.2396
INFO - 2016-05-03 06:12:15 --> Config Class Initialized
INFO - 2016-05-03 06:12:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:12:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:12:15 --> Utf8 Class Initialized
INFO - 2016-05-03 06:12:15 --> URI Class Initialized
INFO - 2016-05-03 06:12:15 --> Router Class Initialized
INFO - 2016-05-03 06:12:15 --> Output Class Initialized
INFO - 2016-05-03 06:12:15 --> Security Class Initialized
DEBUG - 2016-05-03 06:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:12:16 --> Input Class Initialized
INFO - 2016-05-03 06:12:16 --> Language Class Initialized
INFO - 2016-05-03 06:12:16 --> Loader Class Initialized
INFO - 2016-05-03 06:12:16 --> Helper loaded: url_helper
INFO - 2016-05-03 06:12:16 --> Database Driver Class Initialized
INFO - 2016-05-03 06:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:12:16 --> Controller Class Initialized
DEBUG - 2016-05-03 06:12:16 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:12:16 --> Email Class Initialized
INFO - 2016-05-03 06:12:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:12:16 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:12:16 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:12:16 --> Model Class Initialized
INFO - 2016-05-03 06:12:16 --> Helper loaded: date_helper
INFO - 2016-05-03 06:12:16 --> Helper loaded: form_helper
INFO - 2016-05-03 06:12:16 --> Form Validation Class Initialized
INFO - 2016-05-03 06:12:16 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:14:38 --> Config Class Initialized
INFO - 2016-05-03 06:14:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:14:38 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:14:38 --> Utf8 Class Initialized
INFO - 2016-05-03 06:14:38 --> URI Class Initialized
DEBUG - 2016-05-03 06:14:38 --> No URI present. Default controller set.
INFO - 2016-05-03 06:14:38 --> Router Class Initialized
INFO - 2016-05-03 06:14:38 --> Output Class Initialized
INFO - 2016-05-03 06:14:38 --> Security Class Initialized
DEBUG - 2016-05-03 06:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:14:38 --> Input Class Initialized
INFO - 2016-05-03 06:14:38 --> Language Class Initialized
INFO - 2016-05-03 06:14:38 --> Loader Class Initialized
INFO - 2016-05-03 06:14:38 --> Helper loaded: url_helper
INFO - 2016-05-03 06:14:38 --> Database Driver Class Initialized
INFO - 2016-05-03 06:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:14:38 --> Controller Class Initialized
INFO - 2016-05-03 06:14:38 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:14:38 --> Final output sent to browser
DEBUG - 2016-05-03 06:14:38 --> Total execution time: 0.1766
INFO - 2016-05-03 06:14:44 --> Config Class Initialized
INFO - 2016-05-03 06:14:44 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:14:44 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:14:44 --> Utf8 Class Initialized
INFO - 2016-05-03 06:14:44 --> URI Class Initialized
INFO - 2016-05-03 06:14:44 --> Router Class Initialized
INFO - 2016-05-03 06:14:44 --> Output Class Initialized
INFO - 2016-05-03 06:14:44 --> Security Class Initialized
DEBUG - 2016-05-03 06:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:14:44 --> Input Class Initialized
INFO - 2016-05-03 06:14:44 --> Language Class Initialized
INFO - 2016-05-03 06:14:44 --> Loader Class Initialized
INFO - 2016-05-03 06:14:44 --> Helper loaded: url_helper
INFO - 2016-05-03 06:14:44 --> Database Driver Class Initialized
INFO - 2016-05-03 06:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:14:44 --> Controller Class Initialized
INFO - 2016-05-03 06:14:50 --> Config Class Initialized
INFO - 2016-05-03 06:14:50 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:14:50 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:14:50 --> Utf8 Class Initialized
INFO - 2016-05-03 06:14:50 --> URI Class Initialized
INFO - 2016-05-03 06:14:50 --> Router Class Initialized
INFO - 2016-05-03 06:14:50 --> Output Class Initialized
INFO - 2016-05-03 06:14:50 --> Security Class Initialized
DEBUG - 2016-05-03 06:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:14:50 --> Input Class Initialized
INFO - 2016-05-03 06:14:50 --> Language Class Initialized
INFO - 2016-05-03 06:14:50 --> Loader Class Initialized
INFO - 2016-05-03 06:14:50 --> Helper loaded: url_helper
INFO - 2016-05-03 06:14:50 --> Database Driver Class Initialized
INFO - 2016-05-03 06:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:14:51 --> Controller Class Initialized
INFO - 2016-05-03 06:18:30 --> Config Class Initialized
INFO - 2016-05-03 06:18:30 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:18:30 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:18:30 --> Utf8 Class Initialized
INFO - 2016-05-03 06:18:30 --> URI Class Initialized
DEBUG - 2016-05-03 06:18:30 --> No URI present. Default controller set.
INFO - 2016-05-03 06:18:30 --> Router Class Initialized
INFO - 2016-05-03 06:18:30 --> Output Class Initialized
INFO - 2016-05-03 06:18:30 --> Security Class Initialized
DEBUG - 2016-05-03 06:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:18:30 --> Input Class Initialized
INFO - 2016-05-03 06:18:30 --> Language Class Initialized
INFO - 2016-05-03 06:18:30 --> Loader Class Initialized
INFO - 2016-05-03 06:18:30 --> Helper loaded: url_helper
INFO - 2016-05-03 06:18:30 --> Database Driver Class Initialized
INFO - 2016-05-03 06:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:18:30 --> Controller Class Initialized
INFO - 2016-05-03 06:18:30 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:18:30 --> Final output sent to browser
DEBUG - 2016-05-03 06:18:30 --> Total execution time: 0.1645
INFO - 2016-05-03 06:18:36 --> Config Class Initialized
INFO - 2016-05-03 06:18:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:18:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:18:37 --> Utf8 Class Initialized
INFO - 2016-05-03 06:18:37 --> URI Class Initialized
INFO - 2016-05-03 06:18:37 --> Router Class Initialized
INFO - 2016-05-03 06:18:37 --> Output Class Initialized
INFO - 2016-05-03 06:18:37 --> Security Class Initialized
DEBUG - 2016-05-03 06:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:18:37 --> Input Class Initialized
INFO - 2016-05-03 06:18:37 --> Language Class Initialized
INFO - 2016-05-03 06:18:37 --> Loader Class Initialized
INFO - 2016-05-03 06:18:37 --> Helper loaded: url_helper
INFO - 2016-05-03 06:18:37 --> Database Driver Class Initialized
INFO - 2016-05-03 06:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:18:37 --> Controller Class Initialized
INFO - 2016-05-03 06:18:54 --> Config Class Initialized
INFO - 2016-05-03 06:18:54 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:18:54 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:18:54 --> Utf8 Class Initialized
INFO - 2016-05-03 06:18:54 --> URI Class Initialized
DEBUG - 2016-05-03 06:18:54 --> No URI present. Default controller set.
INFO - 2016-05-03 06:18:54 --> Router Class Initialized
INFO - 2016-05-03 06:18:54 --> Output Class Initialized
INFO - 2016-05-03 06:18:54 --> Security Class Initialized
DEBUG - 2016-05-03 06:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:18:54 --> Input Class Initialized
INFO - 2016-05-03 06:18:54 --> Language Class Initialized
INFO - 2016-05-03 06:18:54 --> Loader Class Initialized
INFO - 2016-05-03 06:18:54 --> Helper loaded: url_helper
INFO - 2016-05-03 06:18:54 --> Database Driver Class Initialized
INFO - 2016-05-03 06:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:18:54 --> Controller Class Initialized
DEBUG - 2016-05-03 06:18:54 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:18:54 --> Email Class Initialized
INFO - 2016-05-03 06:18:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:18:54 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:18:54 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:18:54 --> Model Class Initialized
INFO - 2016-05-03 06:18:54 --> Helper loaded: date_helper
INFO - 2016-05-03 06:18:54 --> Helper loaded: form_helper
INFO - 2016-05-03 06:18:54 --> Form Validation Class Initialized
INFO - 2016-05-03 06:18:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:18:54 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:18:54 --> Final output sent to browser
DEBUG - 2016-05-03 06:18:54 --> Total execution time: 0.2805
INFO - 2016-05-03 06:19:03 --> Config Class Initialized
INFO - 2016-05-03 06:19:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:19:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:19:03 --> Utf8 Class Initialized
INFO - 2016-05-03 06:19:03 --> URI Class Initialized
INFO - 2016-05-03 06:19:03 --> Router Class Initialized
INFO - 2016-05-03 06:19:03 --> Output Class Initialized
INFO - 2016-05-03 06:19:03 --> Security Class Initialized
DEBUG - 2016-05-03 06:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:19:03 --> Input Class Initialized
INFO - 2016-05-03 06:19:03 --> Language Class Initialized
INFO - 2016-05-03 06:19:03 --> Loader Class Initialized
INFO - 2016-05-03 06:19:03 --> Helper loaded: url_helper
INFO - 2016-05-03 06:19:03 --> Database Driver Class Initialized
INFO - 2016-05-03 06:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:19:03 --> Controller Class Initialized
DEBUG - 2016-05-03 06:19:03 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:19:03 --> Email Class Initialized
INFO - 2016-05-03 06:19:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:19:03 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:19:03 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:19:03 --> Model Class Initialized
INFO - 2016-05-03 06:19:03 --> Helper loaded: date_helper
INFO - 2016-05-03 06:19:03 --> Helper loaded: form_helper
INFO - 2016-05-03 06:19:03 --> Form Validation Class Initialized
INFO - 2016-05-03 06:19:03 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:23:57 --> Config Class Initialized
INFO - 2016-05-03 06:23:57 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:23:57 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:23:57 --> Utf8 Class Initialized
INFO - 2016-05-03 06:23:57 --> URI Class Initialized
INFO - 2016-05-03 06:23:57 --> Router Class Initialized
INFO - 2016-05-03 06:23:57 --> Output Class Initialized
INFO - 2016-05-03 06:23:57 --> Security Class Initialized
DEBUG - 2016-05-03 06:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:23:57 --> Input Class Initialized
INFO - 2016-05-03 06:23:57 --> Language Class Initialized
INFO - 2016-05-03 06:23:57 --> Loader Class Initialized
INFO - 2016-05-03 06:23:57 --> Helper loaded: url_helper
INFO - 2016-05-03 06:23:57 --> Database Driver Class Initialized
INFO - 2016-05-03 06:23:57 --> Config Class Initialized
INFO - 2016-05-03 06:23:57 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:23:57 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:23:57 --> Utf8 Class Initialized
INFO - 2016-05-03 06:23:57 --> URI Class Initialized
DEBUG - 2016-05-03 06:23:57 --> No URI present. Default controller set.
INFO - 2016-05-03 06:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:23:57 --> Router Class Initialized
INFO - 2016-05-03 06:23:57 --> Controller Class Initialized
DEBUG - 2016-05-03 06:23:57 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:23:57 --> Email Class Initialized
INFO - 2016-05-03 06:23:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:23:57 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:23:57 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:23:58 --> Model Class Initialized
INFO - 2016-05-03 06:23:58 --> Helper loaded: date_helper
INFO - 2016-05-03 06:23:58 --> Helper loaded: form_helper
INFO - 2016-05-03 06:23:58 --> Form Validation Class Initialized
INFO - 2016-05-03 06:23:58 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:23:58 --> Output Class Initialized
INFO - 2016-05-03 06:23:58 --> Security Class Initialized
DEBUG - 2016-05-03 06:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:23:58 --> Input Class Initialized
INFO - 2016-05-03 06:23:58 --> Language Class Initialized
INFO - 2016-05-03 06:23:58 --> Loader Class Initialized
INFO - 2016-05-03 06:23:58 --> Helper loaded: url_helper
INFO - 2016-05-03 06:23:58 --> Database Driver Class Initialized
INFO - 2016-05-03 06:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:23:58 --> Controller Class Initialized
DEBUG - 2016-05-03 06:23:58 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:23:59 --> Email Class Initialized
INFO - 2016-05-03 06:23:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:23:59 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:23:59 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:23:59 --> Model Class Initialized
INFO - 2016-05-03 06:23:59 --> Helper loaded: date_helper
INFO - 2016-05-03 06:23:59 --> Config Class Initialized
INFO - 2016-05-03 06:23:59 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:23:59 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:23:59 --> Utf8 Class Initialized
INFO - 2016-05-03 06:23:59 --> URI Class Initialized
INFO - 2016-05-03 06:23:59 --> Router Class Initialized
INFO - 2016-05-03 06:23:59 --> Output Class Initialized
INFO - 2016-05-03 06:23:59 --> Helper loaded: form_helper
INFO - 2016-05-03 06:23:59 --> Security Class Initialized
DEBUG - 2016-05-03 06:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:23:59 --> Input Class Initialized
INFO - 2016-05-03 06:23:59 --> Config Class Initialized
INFO - 2016-05-03 06:23:59 --> Form Validation Class Initialized
INFO - 2016-05-03 06:23:59 --> Language Class Initialized
INFO - 2016-05-03 06:23:59 --> Hooks Class Initialized
INFO - 2016-05-03 06:23:59 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:23:59 --> Loader Class Initialized
INFO - 2016-05-03 06:23:59 --> Helper loaded: url_helper
DEBUG - 2016-05-03 06:23:59 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:23:59 --> Utf8 Class Initialized
INFO - 2016-05-03 06:23:59 --> URI Class Initialized
INFO - 2016-05-03 06:23:59 --> Database Driver Class Initialized
DEBUG - 2016-05-03 06:23:59 --> No URI present. Default controller set.
INFO - 2016-05-03 06:23:59 --> Router Class Initialized
INFO - 2016-05-03 06:23:59 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:23:59 --> Output Class Initialized
INFO - 2016-05-03 06:23:59 --> Final output sent to browser
INFO - 2016-05-03 06:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:23:59 --> Controller Class Initialized
INFO - 2016-05-03 06:23:59 --> Security Class Initialized
DEBUG - 2016-05-03 06:23:59 --> Total execution time: 1.6293
DEBUG - 2016-05-03 06:23:59 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
DEBUG - 2016-05-03 06:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:23:59 --> Email Class Initialized
INFO - 2016-05-03 06:23:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:23:59 --> Input Class Initialized
INFO - 2016-05-03 06:23:59 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:23:59 --> Language Class Initialized
INFO - 2016-05-03 06:23:59 --> Helper loaded: language_helper
INFO - 2016-05-03 06:23:59 --> Loader Class Initialized
DEBUG - 2016-05-03 06:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:23:59 --> Helper loaded: url_helper
INFO - 2016-05-03 06:23:59 --> Model Class Initialized
INFO - 2016-05-03 06:23:59 --> Helper loaded: date_helper
INFO - 2016-05-03 06:23:59 --> Database Driver Class Initialized
INFO - 2016-05-03 06:23:59 --> Helper loaded: form_helper
INFO - 2016-05-03 06:23:59 --> Form Validation Class Initialized
INFO - 2016-05-03 06:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:23:59 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:23:59 --> Controller Class Initialized
DEBUG - 2016-05-03 06:23:59 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:23:59 --> Email Class Initialized
INFO - 2016-05-03 06:23:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:23:59 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:23:59 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:23:59 --> Model Class Initialized
INFO - 2016-05-03 06:23:59 --> Helper loaded: date_helper
INFO - 2016-05-03 06:23:59 --> Helper loaded: form_helper
INFO - 2016-05-03 06:23:59 --> Form Validation Class Initialized
INFO - 2016-05-03 06:23:59 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:23:59 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:24:00 --> Final output sent to browser
DEBUG - 2016-05-03 06:24:00 --> Total execution time: 0.8416
INFO - 2016-05-03 06:33:24 --> Config Class Initialized
INFO - 2016-05-03 06:33:24 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:33:24 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:33:24 --> Utf8 Class Initialized
INFO - 2016-05-03 06:33:24 --> URI Class Initialized
DEBUG - 2016-05-03 06:33:24 --> No URI present. Default controller set.
INFO - 2016-05-03 06:33:24 --> Router Class Initialized
INFO - 2016-05-03 06:33:24 --> Output Class Initialized
INFO - 2016-05-03 06:33:24 --> Security Class Initialized
DEBUG - 2016-05-03 06:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:33:24 --> Input Class Initialized
INFO - 2016-05-03 06:33:24 --> Language Class Initialized
INFO - 2016-05-03 06:33:24 --> Loader Class Initialized
INFO - 2016-05-03 06:33:24 --> Helper loaded: url_helper
INFO - 2016-05-03 06:33:24 --> Database Driver Class Initialized
INFO - 2016-05-03 06:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:33:24 --> Controller Class Initialized
DEBUG - 2016-05-03 06:33:24 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:33:24 --> Email Class Initialized
INFO - 2016-05-03 06:33:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:33:24 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:33:24 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:33:24 --> Model Class Initialized
INFO - 2016-05-03 06:33:24 --> Helper loaded: date_helper
INFO - 2016-05-03 06:33:24 --> Helper loaded: form_helper
INFO - 2016-05-03 06:33:24 --> Form Validation Class Initialized
INFO - 2016-05-03 06:33:24 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:33:24 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:33:24 --> Final output sent to browser
DEBUG - 2016-05-03 06:33:24 --> Total execution time: 0.3642
INFO - 2016-05-03 06:33:31 --> Config Class Initialized
INFO - 2016-05-03 06:33:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:33:31 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:33:31 --> Utf8 Class Initialized
INFO - 2016-05-03 06:33:31 --> Config Class Initialized
INFO - 2016-05-03 06:33:31 --> Hooks Class Initialized
INFO - 2016-05-03 06:33:31 --> URI Class Initialized
DEBUG - 2016-05-03 06:33:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 06:33:31 --> No URI present. Default controller set.
INFO - 2016-05-03 06:33:31 --> Router Class Initialized
INFO - 2016-05-03 06:33:31 --> Utf8 Class Initialized
INFO - 2016-05-03 06:33:31 --> URI Class Initialized
INFO - 2016-05-03 06:33:31 --> Output Class Initialized
INFO - 2016-05-03 06:33:31 --> Router Class Initialized
INFO - 2016-05-03 06:33:31 --> Security Class Initialized
INFO - 2016-05-03 06:33:31 --> Output Class Initialized
DEBUG - 2016-05-03 06:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:33:31 --> Input Class Initialized
INFO - 2016-05-03 06:33:31 --> Security Class Initialized
INFO - 2016-05-03 06:33:31 --> Language Class Initialized
DEBUG - 2016-05-03 06:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:33:31 --> Loader Class Initialized
INFO - 2016-05-03 06:33:31 --> Input Class Initialized
INFO - 2016-05-03 06:33:31 --> Helper loaded: url_helper
INFO - 2016-05-03 06:33:31 --> Language Class Initialized
INFO - 2016-05-03 06:33:31 --> Database Driver Class Initialized
INFO - 2016-05-03 06:33:31 --> Loader Class Initialized
INFO - 2016-05-03 06:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:33:31 --> Helper loaded: url_helper
INFO - 2016-05-03 06:33:31 --> Controller Class Initialized
DEBUG - 2016-05-03 06:33:31 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:33:31 --> Database Driver Class Initialized
INFO - 2016-05-03 06:33:31 --> Email Class Initialized
INFO - 2016-05-03 06:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:33:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:33:31 --> Controller Class Initialized
INFO - 2016-05-03 06:33:31 --> Helper loaded: cookie_helper
DEBUG - 2016-05-03 06:33:31 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:33:31 --> Helper loaded: language_helper
INFO - 2016-05-03 06:33:31 --> Email Class Initialized
DEBUG - 2016-05-03 06:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:33:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:33:31 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:33:31 --> Model Class Initialized
INFO - 2016-05-03 06:33:31 --> Helper loaded: language_helper
INFO - 2016-05-03 06:33:31 --> Helper loaded: date_helper
DEBUG - 2016-05-03 06:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:33:31 --> Helper loaded: form_helper
INFO - 2016-05-03 06:33:31 --> Model Class Initialized
INFO - 2016-05-03 06:33:31 --> Form Validation Class Initialized
INFO - 2016-05-03 06:33:31 --> Helper loaded: date_helper
INFO - 2016-05-03 06:33:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:33:31 --> Helper loaded: form_helper
INFO - 2016-05-03 06:33:31 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:33:31 --> Form Validation Class Initialized
INFO - 2016-05-03 06:33:31 --> Final output sent to browser
DEBUG - 2016-05-03 06:33:31 --> Total execution time: 0.4546
INFO - 2016-05-03 06:33:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:35:29 --> Config Class Initialized
INFO - 2016-05-03 06:35:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:35:29 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:35:29 --> Utf8 Class Initialized
INFO - 2016-05-03 06:35:29 --> URI Class Initialized
INFO - 2016-05-03 06:35:29 --> Router Class Initialized
INFO - 2016-05-03 06:35:29 --> Output Class Initialized
INFO - 2016-05-03 06:35:29 --> Security Class Initialized
DEBUG - 2016-05-03 06:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:35:29 --> Input Class Initialized
INFO - 2016-05-03 06:35:29 --> Language Class Initialized
INFO - 2016-05-03 06:35:29 --> Loader Class Initialized
INFO - 2016-05-03 06:35:29 --> Helper loaded: url_helper
INFO - 2016-05-03 06:35:29 --> Database Driver Class Initialized
INFO - 2016-05-03 06:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:35:30 --> Controller Class Initialized
DEBUG - 2016-05-03 06:35:30 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:35:30 --> Email Class Initialized
INFO - 2016-05-03 06:35:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:35:30 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:35:30 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:35:30 --> Model Class Initialized
INFO - 2016-05-03 06:35:30 --> Helper loaded: date_helper
INFO - 2016-05-03 06:35:30 --> Helper loaded: form_helper
INFO - 2016-05-03 06:35:30 --> Form Validation Class Initialized
INFO - 2016-05-03 06:35:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:36:02 --> Config Class Initialized
INFO - 2016-05-03 06:36:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:36:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:36:03 --> Config Class Initialized
INFO - 2016-05-03 06:36:03 --> Utf8 Class Initialized
INFO - 2016-05-03 06:36:03 --> Hooks Class Initialized
INFO - 2016-05-03 06:36:03 --> URI Class Initialized
DEBUG - 2016-05-03 06:36:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 06:36:03 --> No URI present. Default controller set.
INFO - 2016-05-03 06:36:03 --> Utf8 Class Initialized
INFO - 2016-05-03 06:36:03 --> Router Class Initialized
INFO - 2016-05-03 06:36:03 --> URI Class Initialized
INFO - 2016-05-03 06:36:03 --> Output Class Initialized
INFO - 2016-05-03 06:36:03 --> Router Class Initialized
INFO - 2016-05-03 06:36:03 --> Security Class Initialized
INFO - 2016-05-03 06:36:03 --> Output Class Initialized
DEBUG - 2016-05-03 06:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:36:03 --> Security Class Initialized
INFO - 2016-05-03 06:36:03 --> Input Class Initialized
DEBUG - 2016-05-03 06:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:36:03 --> Language Class Initialized
INFO - 2016-05-03 06:36:03 --> Input Class Initialized
INFO - 2016-05-03 06:36:03 --> Loader Class Initialized
INFO - 2016-05-03 06:36:03 --> Language Class Initialized
INFO - 2016-05-03 06:36:03 --> Helper loaded: url_helper
INFO - 2016-05-03 06:36:03 --> Loader Class Initialized
INFO - 2016-05-03 06:36:03 --> Database Driver Class Initialized
INFO - 2016-05-03 06:36:03 --> Helper loaded: url_helper
INFO - 2016-05-03 06:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:36:03 --> Controller Class Initialized
INFO - 2016-05-03 06:36:03 --> Database Driver Class Initialized
DEBUG - 2016-05-03 06:36:03 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:36:03 --> Email Class Initialized
INFO - 2016-05-03 06:36:03 --> Controller Class Initialized
INFO - 2016-05-03 06:36:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-03 06:36:03 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:36:03 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:36:03 --> Email Class Initialized
INFO - 2016-05-03 06:36:03 --> Helper loaded: language_helper
INFO - 2016-05-03 06:36:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-03 06:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:36:03 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:36:03 --> Model Class Initialized
INFO - 2016-05-03 06:36:03 --> Helper loaded: language_helper
INFO - 2016-05-03 06:36:03 --> Helper loaded: date_helper
DEBUG - 2016-05-03 06:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:36:03 --> Helper loaded: form_helper
INFO - 2016-05-03 06:36:03 --> Form Validation Class Initialized
INFO - 2016-05-03 06:36:03 --> Model Class Initialized
INFO - 2016-05-03 06:36:03 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:36:03 --> Helper loaded: date_helper
INFO - 2016-05-03 06:36:03 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:36:03 --> Helper loaded: form_helper
INFO - 2016-05-03 06:36:03 --> Form Validation Class Initialized
INFO - 2016-05-03 06:36:03 --> Final output sent to browser
INFO - 2016-05-03 06:36:03 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2016-05-03 06:36:03 --> Total execution time: 0.5002
INFO - 2016-05-03 06:36:17 --> Config Class Initialized
INFO - 2016-05-03 06:36:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:36:17 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:36:17 --> Utf8 Class Initialized
INFO - 2016-05-03 06:36:17 --> URI Class Initialized
INFO - 2016-05-03 06:36:17 --> Router Class Initialized
INFO - 2016-05-03 06:36:17 --> Output Class Initialized
INFO - 2016-05-03 06:36:17 --> Security Class Initialized
DEBUG - 2016-05-03 06:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:36:17 --> Input Class Initialized
INFO - 2016-05-03 06:36:17 --> Language Class Initialized
INFO - 2016-05-03 06:36:17 --> Loader Class Initialized
INFO - 2016-05-03 06:36:17 --> Helper loaded: url_helper
INFO - 2016-05-03 06:36:17 --> Database Driver Class Initialized
INFO - 2016-05-03 06:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:36:17 --> Controller Class Initialized
DEBUG - 2016-05-03 06:36:17 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:36:17 --> Email Class Initialized
INFO - 2016-05-03 06:36:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:36:17 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:36:17 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:36:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:36:17 --> Model Class Initialized
INFO - 2016-05-03 06:36:17 --> Helper loaded: date_helper
INFO - 2016-05-03 06:36:17 --> Helper loaded: form_helper
INFO - 2016-05-03 06:36:17 --> Form Validation Class Initialized
INFO - 2016-05-03 06:36:17 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:37:09 --> Config Class Initialized
INFO - 2016-05-03 06:37:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:37:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:37:10 --> Utf8 Class Initialized
INFO - 2016-05-03 06:37:10 --> URI Class Initialized
DEBUG - 2016-05-03 06:37:10 --> No URI present. Default controller set.
INFO - 2016-05-03 06:37:10 --> Router Class Initialized
INFO - 2016-05-03 06:37:10 --> Output Class Initialized
INFO - 2016-05-03 06:37:10 --> Security Class Initialized
DEBUG - 2016-05-03 06:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:37:10 --> Input Class Initialized
INFO - 2016-05-03 06:37:10 --> Language Class Initialized
INFO - 2016-05-03 06:37:10 --> Loader Class Initialized
INFO - 2016-05-03 06:37:10 --> Helper loaded: url_helper
INFO - 2016-05-03 06:37:10 --> Database Driver Class Initialized
INFO - 2016-05-03 06:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:37:10 --> Controller Class Initialized
DEBUG - 2016-05-03 06:37:10 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:37:10 --> Email Class Initialized
INFO - 2016-05-03 06:37:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:37:10 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:37:10 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:37:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:37:10 --> Model Class Initialized
INFO - 2016-05-03 06:37:10 --> Helper loaded: date_helper
INFO - 2016-05-03 06:37:10 --> Helper loaded: form_helper
INFO - 2016-05-03 06:37:10 --> Form Validation Class Initialized
INFO - 2016-05-03 06:37:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:37:10 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:37:10 --> Final output sent to browser
DEBUG - 2016-05-03 06:37:10 --> Total execution time: 0.2821
INFO - 2016-05-03 06:37:20 --> Config Class Initialized
INFO - 2016-05-03 06:37:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:37:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:37:20 --> Utf8 Class Initialized
INFO - 2016-05-03 06:37:20 --> URI Class Initialized
INFO - 2016-05-03 06:37:20 --> Router Class Initialized
INFO - 2016-05-03 06:37:20 --> Output Class Initialized
INFO - 2016-05-03 06:37:20 --> Security Class Initialized
DEBUG - 2016-05-03 06:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:37:20 --> Input Class Initialized
INFO - 2016-05-03 06:37:20 --> Language Class Initialized
INFO - 2016-05-03 06:37:20 --> Loader Class Initialized
INFO - 2016-05-03 06:37:20 --> Helper loaded: url_helper
INFO - 2016-05-03 06:37:20 --> Database Driver Class Initialized
INFO - 2016-05-03 06:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:37:20 --> Controller Class Initialized
DEBUG - 2016-05-03 06:37:20 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:37:20 --> Email Class Initialized
INFO - 2016-05-03 06:37:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:37:20 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:37:20 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:37:20 --> Model Class Initialized
INFO - 2016-05-03 06:37:20 --> Helper loaded: date_helper
INFO - 2016-05-03 06:37:20 --> Helper loaded: form_helper
INFO - 2016-05-03 06:37:20 --> Form Validation Class Initialized
INFO - 2016-05-03 06:37:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:37:20 --> Final output sent to browser
DEBUG - 2016-05-03 06:37:20 --> Total execution time: 0.2809
INFO - 2016-05-03 06:37:26 --> Config Class Initialized
INFO - 2016-05-03 06:37:26 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:37:26 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:37:26 --> Utf8 Class Initialized
INFO - 2016-05-03 06:37:26 --> URI Class Initialized
DEBUG - 2016-05-03 06:37:26 --> No URI present. Default controller set.
INFO - 2016-05-03 06:37:26 --> Router Class Initialized
INFO - 2016-05-03 06:37:26 --> Output Class Initialized
INFO - 2016-05-03 06:37:26 --> Security Class Initialized
DEBUG - 2016-05-03 06:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:37:26 --> Input Class Initialized
INFO - 2016-05-03 06:37:26 --> Language Class Initialized
INFO - 2016-05-03 06:37:26 --> Loader Class Initialized
INFO - 2016-05-03 06:37:26 --> Helper loaded: url_helper
INFO - 2016-05-03 06:37:26 --> Database Driver Class Initialized
INFO - 2016-05-03 06:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:37:26 --> Controller Class Initialized
DEBUG - 2016-05-03 06:37:26 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:37:26 --> Email Class Initialized
INFO - 2016-05-03 06:37:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:37:26 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:37:26 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:37:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:37:26 --> Model Class Initialized
INFO - 2016-05-03 06:37:27 --> Helper loaded: date_helper
INFO - 2016-05-03 06:37:27 --> Helper loaded: form_helper
INFO - 2016-05-03 06:37:27 --> Form Validation Class Initialized
INFO - 2016-05-03 06:37:27 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:37:27 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:37:27 --> Final output sent to browser
DEBUG - 2016-05-03 06:37:27 --> Total execution time: 0.2842
INFO - 2016-05-03 06:39:53 --> Config Class Initialized
INFO - 2016-05-03 06:39:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:39:53 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:39:53 --> Utf8 Class Initialized
INFO - 2016-05-03 06:39:53 --> URI Class Initialized
DEBUG - 2016-05-03 06:39:53 --> No URI present. Default controller set.
INFO - 2016-05-03 06:39:53 --> Router Class Initialized
INFO - 2016-05-03 06:39:53 --> Output Class Initialized
INFO - 2016-05-03 06:39:53 --> Security Class Initialized
DEBUG - 2016-05-03 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:39:53 --> Input Class Initialized
INFO - 2016-05-03 06:39:53 --> Language Class Initialized
INFO - 2016-05-03 06:39:53 --> Loader Class Initialized
INFO - 2016-05-03 06:39:53 --> Helper loaded: url_helper
INFO - 2016-05-03 06:39:53 --> Database Driver Class Initialized
INFO - 2016-05-03 06:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:39:54 --> Controller Class Initialized
DEBUG - 2016-05-03 06:39:54 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:39:54 --> Email Class Initialized
INFO - 2016-05-03 06:39:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:39:54 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:39:54 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:39:54 --> Model Class Initialized
INFO - 2016-05-03 06:39:54 --> Helper loaded: date_helper
INFO - 2016-05-03 06:39:54 --> Helper loaded: form_helper
INFO - 2016-05-03 06:39:54 --> Form Validation Class Initialized
INFO - 2016-05-03 06:39:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:39:54 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:39:54 --> Final output sent to browser
DEBUG - 2016-05-03 06:39:54 --> Total execution time: 0.3349
INFO - 2016-05-03 06:40:03 --> Config Class Initialized
INFO - 2016-05-03 06:40:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:40:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:40:04 --> Utf8 Class Initialized
INFO - 2016-05-03 06:40:04 --> URI Class Initialized
INFO - 2016-05-03 06:40:04 --> Router Class Initialized
INFO - 2016-05-03 06:40:04 --> Output Class Initialized
INFO - 2016-05-03 06:40:04 --> Security Class Initialized
DEBUG - 2016-05-03 06:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:40:04 --> Input Class Initialized
INFO - 2016-05-03 06:40:04 --> Language Class Initialized
INFO - 2016-05-03 06:40:04 --> Loader Class Initialized
INFO - 2016-05-03 06:40:04 --> Helper loaded: url_helper
INFO - 2016-05-03 06:40:04 --> Database Driver Class Initialized
INFO - 2016-05-03 06:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:40:04 --> Controller Class Initialized
DEBUG - 2016-05-03 06:40:04 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:40:04 --> Email Class Initialized
INFO - 2016-05-03 06:40:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:40:04 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:40:04 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:40:04 --> Model Class Initialized
INFO - 2016-05-03 06:40:04 --> Helper loaded: date_helper
INFO - 2016-05-03 06:40:04 --> Helper loaded: form_helper
INFO - 2016-05-03 06:40:04 --> Form Validation Class Initialized
INFO - 2016-05-03 06:40:04 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:40:04 --> Final output sent to browser
DEBUG - 2016-05-03 06:40:04 --> Total execution time: 0.2775
INFO - 2016-05-03 06:41:31 --> Config Class Initialized
INFO - 2016-05-03 06:41:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:41:31 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:41:31 --> Utf8 Class Initialized
INFO - 2016-05-03 06:41:31 --> URI Class Initialized
DEBUG - 2016-05-03 06:41:31 --> No URI present. Default controller set.
INFO - 2016-05-03 06:41:31 --> Router Class Initialized
INFO - 2016-05-03 06:41:31 --> Output Class Initialized
INFO - 2016-05-03 06:41:31 --> Security Class Initialized
DEBUG - 2016-05-03 06:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:41:31 --> CSRF cookie sent
INFO - 2016-05-03 06:41:31 --> Input Class Initialized
INFO - 2016-05-03 06:41:31 --> Language Class Initialized
INFO - 2016-05-03 06:41:31 --> Loader Class Initialized
INFO - 2016-05-03 06:41:31 --> Helper loaded: url_helper
INFO - 2016-05-03 06:41:31 --> Database Driver Class Initialized
INFO - 2016-05-03 06:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:41:31 --> Controller Class Initialized
DEBUG - 2016-05-03 06:41:31 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:41:31 --> Email Class Initialized
INFO - 2016-05-03 06:41:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:41:31 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:41:31 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:41:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:41:31 --> Model Class Initialized
INFO - 2016-05-03 06:41:31 --> Helper loaded: date_helper
INFO - 2016-05-03 06:41:31 --> Helper loaded: form_helper
INFO - 2016-05-03 06:41:31 --> Form Validation Class Initialized
INFO - 2016-05-03 06:41:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:41:31 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:41:31 --> Final output sent to browser
DEBUG - 2016-05-03 06:41:31 --> Total execution time: 0.2989
INFO - 2016-05-03 06:41:50 --> Config Class Initialized
INFO - 2016-05-03 06:41:50 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:41:50 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:41:50 --> Utf8 Class Initialized
INFO - 2016-05-03 06:41:50 --> URI Class Initialized
INFO - 2016-05-03 06:41:50 --> Router Class Initialized
INFO - 2016-05-03 06:41:50 --> Output Class Initialized
INFO - 2016-05-03 06:41:50 --> Security Class Initialized
DEBUG - 2016-05-03 06:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:42:12 --> Config Class Initialized
INFO - 2016-05-03 06:42:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:42:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:42:12 --> Utf8 Class Initialized
INFO - 2016-05-03 06:42:12 --> URI Class Initialized
DEBUG - 2016-05-03 06:42:13 --> No URI present. Default controller set.
INFO - 2016-05-03 06:42:13 --> Router Class Initialized
INFO - 2016-05-03 06:42:13 --> Output Class Initialized
INFO - 2016-05-03 06:42:13 --> Security Class Initialized
DEBUG - 2016-05-03 06:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:42:13 --> CSRF cookie sent
INFO - 2016-05-03 06:42:13 --> Input Class Initialized
INFO - 2016-05-03 06:42:13 --> Language Class Initialized
INFO - 2016-05-03 06:42:13 --> Loader Class Initialized
INFO - 2016-05-03 06:42:13 --> Helper loaded: url_helper
INFO - 2016-05-03 06:42:13 --> Database Driver Class Initialized
INFO - 2016-05-03 06:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:42:13 --> Controller Class Initialized
DEBUG - 2016-05-03 06:42:13 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:42:13 --> Email Class Initialized
INFO - 2016-05-03 06:42:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:42:13 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:42:13 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:42:13 --> Model Class Initialized
INFO - 2016-05-03 06:42:13 --> Helper loaded: date_helper
INFO - 2016-05-03 06:42:13 --> Helper loaded: form_helper
INFO - 2016-05-03 06:42:13 --> Form Validation Class Initialized
INFO - 2016-05-03 06:42:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:42:13 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:42:13 --> Final output sent to browser
DEBUG - 2016-05-03 06:42:13 --> Total execution time: 0.2884
INFO - 2016-05-03 06:42:36 --> Config Class Initialized
INFO - 2016-05-03 06:42:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:42:36 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:42:36 --> Utf8 Class Initialized
INFO - 2016-05-03 06:42:36 --> URI Class Initialized
DEBUG - 2016-05-03 06:42:36 --> No URI present. Default controller set.
INFO - 2016-05-03 06:42:36 --> Router Class Initialized
INFO - 2016-05-03 06:42:36 --> Output Class Initialized
INFO - 2016-05-03 06:42:36 --> Security Class Initialized
DEBUG - 2016-05-03 06:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:42:36 --> Input Class Initialized
INFO - 2016-05-03 06:42:36 --> Language Class Initialized
INFO - 2016-05-03 06:42:36 --> Loader Class Initialized
INFO - 2016-05-03 06:42:36 --> Helper loaded: url_helper
INFO - 2016-05-03 06:42:36 --> Database Driver Class Initialized
INFO - 2016-05-03 06:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:42:36 --> Controller Class Initialized
DEBUG - 2016-05-03 06:42:36 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:42:36 --> Email Class Initialized
INFO - 2016-05-03 06:42:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:42:36 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:42:36 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:42:36 --> Model Class Initialized
INFO - 2016-05-03 06:42:36 --> Helper loaded: date_helper
INFO - 2016-05-03 06:42:36 --> Helper loaded: form_helper
INFO - 2016-05-03 06:42:36 --> Form Validation Class Initialized
INFO - 2016-05-03 06:42:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:42:36 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:42:36 --> Final output sent to browser
DEBUG - 2016-05-03 06:42:36 --> Total execution time: 0.2852
INFO - 2016-05-03 06:42:46 --> Config Class Initialized
INFO - 2016-05-03 06:42:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:42:46 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:42:46 --> Utf8 Class Initialized
INFO - 2016-05-03 06:42:46 --> Config Class Initialized
INFO - 2016-05-03 06:42:46 --> URI Class Initialized
INFO - 2016-05-03 06:42:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:42:46 --> No URI present. Default controller set.
INFO - 2016-05-03 06:42:46 --> Router Class Initialized
DEBUG - 2016-05-03 06:42:46 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:42:46 --> Output Class Initialized
INFO - 2016-05-03 06:42:46 --> Utf8 Class Initialized
INFO - 2016-05-03 06:42:46 --> Security Class Initialized
INFO - 2016-05-03 06:42:46 --> URI Class Initialized
DEBUG - 2016-05-03 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:42:46 --> Input Class Initialized
INFO - 2016-05-03 06:42:46 --> Router Class Initialized
INFO - 2016-05-03 06:42:46 --> Language Class Initialized
INFO - 2016-05-03 06:42:46 --> Output Class Initialized
INFO - 2016-05-03 06:42:46 --> Loader Class Initialized
INFO - 2016-05-03 06:42:46 --> Security Class Initialized
INFO - 2016-05-03 06:42:46 --> Helper loaded: url_helper
DEBUG - 2016-05-03 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:42:46 --> Input Class Initialized
INFO - 2016-05-03 06:42:46 --> Database Driver Class Initialized
INFO - 2016-05-03 06:42:46 --> Language Class Initialized
INFO - 2016-05-03 06:42:46 --> Loader Class Initialized
INFO - 2016-05-03 06:42:47 --> Helper loaded: url_helper
INFO - 2016-05-03 06:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:42:47 --> Controller Class Initialized
INFO - 2016-05-03 06:42:47 --> Database Driver Class Initialized
DEBUG - 2016-05-03 06:42:47 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:42:47 --> Email Class Initialized
INFO - 2016-05-03 06:42:47 --> Controller Class Initialized
INFO - 2016-05-03 06:42:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-03 06:42:47 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:42:47 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:42:47 --> Email Class Initialized
INFO - 2016-05-03 06:42:47 --> Helper loaded: language_helper
INFO - 2016-05-03 06:42:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-03 06:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:42:47 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:42:47 --> Model Class Initialized
INFO - 2016-05-03 06:42:47 --> Helper loaded: language_helper
INFO - 2016-05-03 06:42:47 --> Helper loaded: date_helper
DEBUG - 2016-05-03 06:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:42:47 --> Model Class Initialized
INFO - 2016-05-03 06:42:47 --> Helper loaded: form_helper
INFO - 2016-05-03 06:42:47 --> Helper loaded: date_helper
INFO - 2016-05-03 06:42:47 --> Form Validation Class Initialized
INFO - 2016-05-03 06:42:47 --> Helper loaded: form_helper
INFO - 2016-05-03 06:42:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:42:47 --> Form Validation Class Initialized
INFO - 2016-05-03 06:42:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:42:47 --> Final output sent to browser
INFO - 2016-05-03 06:42:47 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
DEBUG - 2016-05-03 06:42:47 --> Total execution time: 0.4497
INFO - 2016-05-03 06:42:47 --> Final output sent to browser
DEBUG - 2016-05-03 06:42:47 --> Total execution time: 0.5043
INFO - 2016-05-03 06:42:55 --> Config Class Initialized
INFO - 2016-05-03 06:42:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:42:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:42:55 --> Utf8 Class Initialized
INFO - 2016-05-03 06:42:55 --> URI Class Initialized
INFO - 2016-05-03 06:42:55 --> Router Class Initialized
INFO - 2016-05-03 06:42:55 --> Output Class Initialized
INFO - 2016-05-03 06:42:55 --> Security Class Initialized
DEBUG - 2016-05-03 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:42:55 --> Input Class Initialized
INFO - 2016-05-03 06:42:55 --> Language Class Initialized
INFO - 2016-05-03 06:42:55 --> Loader Class Initialized
INFO - 2016-05-03 06:42:55 --> Helper loaded: url_helper
INFO - 2016-05-03 06:42:55 --> Database Driver Class Initialized
INFO - 2016-05-03 06:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:42:56 --> Controller Class Initialized
DEBUG - 2016-05-03 06:42:56 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:42:56 --> Email Class Initialized
INFO - 2016-05-03 06:42:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:42:56 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:42:56 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:42:56 --> Model Class Initialized
INFO - 2016-05-03 06:42:56 --> Helper loaded: date_helper
INFO - 2016-05-03 06:42:56 --> Helper loaded: form_helper
INFO - 2016-05-03 06:42:56 --> Form Validation Class Initialized
INFO - 2016-05-03 06:42:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:42:56 --> Final output sent to browser
DEBUG - 2016-05-03 06:42:56 --> Total execution time: 0.2985
INFO - 2016-05-03 06:43:11 --> Config Class Initialized
INFO - 2016-05-03 06:43:11 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:43:11 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:43:11 --> Utf8 Class Initialized
INFO - 2016-05-03 06:43:11 --> URI Class Initialized
INFO - 2016-05-03 06:43:11 --> Router Class Initialized
INFO - 2016-05-03 06:43:11 --> Output Class Initialized
INFO - 2016-05-03 06:43:11 --> Security Class Initialized
DEBUG - 2016-05-03 06:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:43:11 --> Input Class Initialized
INFO - 2016-05-03 06:43:11 --> Language Class Initialized
INFO - 2016-05-03 06:43:11 --> Loader Class Initialized
INFO - 2016-05-03 06:43:11 --> Helper loaded: url_helper
INFO - 2016-05-03 06:43:11 --> Database Driver Class Initialized
INFO - 2016-05-03 06:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:43:11 --> Controller Class Initialized
DEBUG - 2016-05-03 06:43:11 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:43:11 --> Email Class Initialized
INFO - 2016-05-03 06:43:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:43:11 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:43:11 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:43:11 --> Model Class Initialized
INFO - 2016-05-03 06:43:11 --> Helper loaded: date_helper
INFO - 2016-05-03 06:43:11 --> Helper loaded: form_helper
INFO - 2016-05-03 06:43:11 --> Form Validation Class Initialized
INFO - 2016-05-03 06:43:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:43:11 --> Final output sent to browser
DEBUG - 2016-05-03 06:43:11 --> Total execution time: 0.3022
INFO - 2016-05-03 06:44:28 --> Config Class Initialized
INFO - 2016-05-03 06:44:28 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:44:28 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:44:28 --> Utf8 Class Initialized
INFO - 2016-05-03 06:44:28 --> URI Class Initialized
DEBUG - 2016-05-03 06:44:28 --> No URI present. Default controller set.
INFO - 2016-05-03 06:44:28 --> Router Class Initialized
INFO - 2016-05-03 06:44:28 --> Output Class Initialized
INFO - 2016-05-03 06:44:28 --> Security Class Initialized
DEBUG - 2016-05-03 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:44:28 --> Input Class Initialized
INFO - 2016-05-03 06:44:28 --> Language Class Initialized
INFO - 2016-05-03 06:44:28 --> Loader Class Initialized
INFO - 2016-05-03 06:44:28 --> Helper loaded: url_helper
INFO - 2016-05-03 06:44:28 --> Database Driver Class Initialized
INFO - 2016-05-03 06:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:44:28 --> Controller Class Initialized
DEBUG - 2016-05-03 06:44:28 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:44:28 --> Email Class Initialized
INFO - 2016-05-03 06:44:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:44:28 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:44:29 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:44:29 --> Model Class Initialized
INFO - 2016-05-03 06:44:29 --> Helper loaded: date_helper
INFO - 2016-05-03 06:44:29 --> Helper loaded: form_helper
INFO - 2016-05-03 06:44:29 --> Form Validation Class Initialized
INFO - 2016-05-03 06:44:29 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:44:29 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:44:29 --> Final output sent to browser
DEBUG - 2016-05-03 06:44:29 --> Total execution time: 0.3042
INFO - 2016-05-03 06:44:37 --> Config Class Initialized
INFO - 2016-05-03 06:44:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:44:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:44:37 --> Utf8 Class Initialized
INFO - 2016-05-03 06:44:37 --> URI Class Initialized
INFO - 2016-05-03 06:44:37 --> Router Class Initialized
INFO - 2016-05-03 06:44:37 --> Output Class Initialized
INFO - 2016-05-03 06:44:37 --> Security Class Initialized
DEBUG - 2016-05-03 06:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:44:37 --> Input Class Initialized
INFO - 2016-05-03 06:44:37 --> Language Class Initialized
INFO - 2016-05-03 06:44:38 --> Loader Class Initialized
INFO - 2016-05-03 06:44:38 --> Helper loaded: url_helper
INFO - 2016-05-03 06:44:38 --> Database Driver Class Initialized
INFO - 2016-05-03 06:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:44:38 --> Controller Class Initialized
DEBUG - 2016-05-03 06:44:38 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:44:38 --> Email Class Initialized
INFO - 2016-05-03 06:44:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:44:38 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:44:38 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:44:38 --> Model Class Initialized
INFO - 2016-05-03 06:44:38 --> Helper loaded: date_helper
INFO - 2016-05-03 06:44:38 --> Helper loaded: form_helper
INFO - 2016-05-03 06:44:38 --> Form Validation Class Initialized
INFO - 2016-05-03 06:44:38 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:44:38 --> Final output sent to browser
DEBUG - 2016-05-03 06:44:38 --> Total execution time: 0.3052
INFO - 2016-05-03 06:45:13 --> Config Class Initialized
INFO - 2016-05-03 06:45:13 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:45:13 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:45:13 --> Utf8 Class Initialized
INFO - 2016-05-03 06:45:13 --> URI Class Initialized
DEBUG - 2016-05-03 06:45:13 --> No URI present. Default controller set.
INFO - 2016-05-03 06:45:13 --> Router Class Initialized
INFO - 2016-05-03 06:45:13 --> Output Class Initialized
INFO - 2016-05-03 06:45:13 --> Security Class Initialized
DEBUG - 2016-05-03 06:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:45:13 --> Input Class Initialized
INFO - 2016-05-03 06:45:13 --> Language Class Initialized
INFO - 2016-05-03 06:45:13 --> Loader Class Initialized
INFO - 2016-05-03 06:45:13 --> Helper loaded: url_helper
INFO - 2016-05-03 06:45:13 --> Database Driver Class Initialized
INFO - 2016-05-03 06:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:45:13 --> Controller Class Initialized
DEBUG - 2016-05-03 06:45:13 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:45:13 --> Email Class Initialized
INFO - 2016-05-03 06:45:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:45:13 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:45:13 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:45:13 --> Model Class Initialized
INFO - 2016-05-03 06:45:13 --> Helper loaded: date_helper
INFO - 2016-05-03 06:45:13 --> Helper loaded: form_helper
INFO - 2016-05-03 06:45:13 --> Form Validation Class Initialized
INFO - 2016-05-03 06:45:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:45:13 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:45:13 --> Final output sent to browser
DEBUG - 2016-05-03 06:45:13 --> Total execution time: 0.3031
INFO - 2016-05-03 06:45:26 --> Config Class Initialized
INFO - 2016-05-03 06:45:26 --> Config Class Initialized
INFO - 2016-05-03 06:45:26 --> Hooks Class Initialized
INFO - 2016-05-03 06:45:26 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:45:26 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:45:26 --> Utf8 Class Initialized
INFO - 2016-05-03 06:45:26 --> URI Class Initialized
DEBUG - 2016-05-03 06:45:26 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:45:26 --> Router Class Initialized
INFO - 2016-05-03 06:45:26 --> Utf8 Class Initialized
INFO - 2016-05-03 06:45:26 --> Output Class Initialized
INFO - 2016-05-03 06:45:26 --> Security Class Initialized
INFO - 2016-05-03 06:45:26 --> URI Class Initialized
DEBUG - 2016-05-03 06:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:45:26 --> Input Class Initialized
DEBUG - 2016-05-03 06:45:26 --> No URI present. Default controller set.
INFO - 2016-05-03 06:45:26 --> Router Class Initialized
INFO - 2016-05-03 06:45:26 --> Language Class Initialized
INFO - 2016-05-03 06:45:26 --> Output Class Initialized
INFO - 2016-05-03 06:45:26 --> Security Class Initialized
INFO - 2016-05-03 06:45:26 --> Loader Class Initialized
INFO - 2016-05-03 06:45:26 --> Helper loaded: url_helper
DEBUG - 2016-05-03 06:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:45:26 --> Database Driver Class Initialized
INFO - 2016-05-03 06:45:26 --> Input Class Initialized
INFO - 2016-05-03 06:45:26 --> Language Class Initialized
INFO - 2016-05-03 06:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:45:26 --> Loader Class Initialized
INFO - 2016-05-03 06:45:26 --> Controller Class Initialized
INFO - 2016-05-03 06:45:26 --> Helper loaded: url_helper
DEBUG - 2016-05-03 06:45:26 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:45:26 --> Database Driver Class Initialized
INFO - 2016-05-03 06:45:26 --> Email Class Initialized
INFO - 2016-05-03 06:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:45:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:45:26 --> Controller Class Initialized
INFO - 2016-05-03 06:45:26 --> Helper loaded: cookie_helper
DEBUG - 2016-05-03 06:45:26 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:45:26 --> Helper loaded: language_helper
INFO - 2016-05-03 06:45:26 --> Email Class Initialized
DEBUG - 2016-05-03 06:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:45:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:45:26 --> Model Class Initialized
INFO - 2016-05-03 06:45:26 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:45:26 --> Helper loaded: date_helper
INFO - 2016-05-03 06:45:26 --> Helper loaded: language_helper
INFO - 2016-05-03 06:45:26 --> Helper loaded: form_helper
DEBUG - 2016-05-03 06:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:45:26 --> Form Validation Class Initialized
INFO - 2016-05-03 06:45:26 --> Model Class Initialized
INFO - 2016-05-03 06:45:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:45:26 --> Helper loaded: date_helper
INFO - 2016-05-03 06:45:26 --> Helper loaded: form_helper
INFO - 2016-05-03 06:45:26 --> Form Validation Class Initialized
INFO - 2016-05-03 06:45:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:45:26 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:45:26 --> Final output sent to browser
DEBUG - 2016-05-03 06:45:26 --> Total execution time: 0.4728
INFO - 2016-05-03 06:45:37 --> Config Class Initialized
INFO - 2016-05-03 06:45:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:45:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:45:37 --> Utf8 Class Initialized
INFO - 2016-05-03 06:45:37 --> URI Class Initialized
INFO - 2016-05-03 06:45:37 --> Router Class Initialized
INFO - 2016-05-03 06:45:37 --> Output Class Initialized
INFO - 2016-05-03 06:45:37 --> Security Class Initialized
DEBUG - 2016-05-03 06:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:45:37 --> Input Class Initialized
INFO - 2016-05-03 06:45:37 --> Language Class Initialized
INFO - 2016-05-03 06:45:37 --> Loader Class Initialized
INFO - 2016-05-03 06:45:37 --> Helper loaded: url_helper
INFO - 2016-05-03 06:45:37 --> Database Driver Class Initialized
INFO - 2016-05-03 06:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:45:37 --> Controller Class Initialized
DEBUG - 2016-05-03 06:45:37 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:45:37 --> Email Class Initialized
INFO - 2016-05-03 06:45:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:45:37 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:45:37 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:45:37 --> Model Class Initialized
INFO - 2016-05-03 06:45:37 --> Helper loaded: date_helper
INFO - 2016-05-03 06:45:37 --> Helper loaded: form_helper
INFO - 2016-05-03 06:45:37 --> Form Validation Class Initialized
INFO - 2016-05-03 06:45:37 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:47:41 --> Config Class Initialized
INFO - 2016-05-03 06:47:41 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:47:41 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:47:41 --> Utf8 Class Initialized
INFO - 2016-05-03 06:47:41 --> URI Class Initialized
INFO - 2016-05-03 06:47:41 --> Router Class Initialized
INFO - 2016-05-03 06:47:41 --> Output Class Initialized
INFO - 2016-05-03 06:47:41 --> Security Class Initialized
DEBUG - 2016-05-03 06:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:47:41 --> Input Class Initialized
INFO - 2016-05-03 06:47:41 --> Language Class Initialized
INFO - 2016-05-03 06:47:41 --> Loader Class Initialized
INFO - 2016-05-03 06:47:41 --> Helper loaded: url_helper
INFO - 2016-05-03 06:47:41 --> Database Driver Class Initialized
INFO - 2016-05-03 06:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:47:42 --> Controller Class Initialized
DEBUG - 2016-05-03 06:47:42 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:47:42 --> Email Class Initialized
INFO - 2016-05-03 06:47:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:47:42 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:47:42 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:47:42 --> Model Class Initialized
INFO - 2016-05-03 06:47:42 --> Helper loaded: date_helper
INFO - 2016-05-03 06:47:42 --> Helper loaded: form_helper
INFO - 2016-05-03 06:47:42 --> Form Validation Class Initialized
INFO - 2016-05-03 06:47:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:47:50 --> Config Class Initialized
INFO - 2016-05-03 06:47:50 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:47:50 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:47:50 --> Utf8 Class Initialized
INFO - 2016-05-03 06:47:50 --> URI Class Initialized
INFO - 2016-05-03 06:47:50 --> Router Class Initialized
INFO - 2016-05-03 06:47:50 --> Output Class Initialized
INFO - 2016-05-03 06:47:50 --> Security Class Initialized
DEBUG - 2016-05-03 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:47:50 --> Input Class Initialized
INFO - 2016-05-03 06:47:50 --> Language Class Initialized
INFO - 2016-05-03 06:47:50 --> Loader Class Initialized
INFO - 2016-05-03 06:47:50 --> Helper loaded: url_helper
INFO - 2016-05-03 06:47:50 --> Database Driver Class Initialized
INFO - 2016-05-03 06:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:47:50 --> Controller Class Initialized
DEBUG - 2016-05-03 06:47:50 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:47:50 --> Email Class Initialized
INFO - 2016-05-03 06:47:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:47:50 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:47:50 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:47:50 --> Model Class Initialized
INFO - 2016-05-03 06:47:50 --> Helper loaded: date_helper
INFO - 2016-05-03 06:47:50 --> Helper loaded: form_helper
INFO - 2016-05-03 06:47:50 --> Form Validation Class Initialized
INFO - 2016-05-03 06:47:50 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:48:41 --> Config Class Initialized
INFO - 2016-05-03 06:48:41 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:48:41 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:48:41 --> Utf8 Class Initialized
INFO - 2016-05-03 06:48:41 --> URI Class Initialized
DEBUG - 2016-05-03 06:48:41 --> No URI present. Default controller set.
INFO - 2016-05-03 06:48:41 --> Router Class Initialized
INFO - 2016-05-03 06:48:41 --> Output Class Initialized
INFO - 2016-05-03 06:48:41 --> Security Class Initialized
DEBUG - 2016-05-03 06:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:48:41 --> Input Class Initialized
INFO - 2016-05-03 06:48:41 --> Language Class Initialized
INFO - 2016-05-03 06:48:41 --> Loader Class Initialized
INFO - 2016-05-03 06:48:41 --> Helper loaded: url_helper
INFO - 2016-05-03 06:48:41 --> Database Driver Class Initialized
INFO - 2016-05-03 06:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:48:41 --> Controller Class Initialized
DEBUG - 2016-05-03 06:48:41 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:48:41 --> Email Class Initialized
INFO - 2016-05-03 06:48:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:48:41 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:48:41 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:48:41 --> Model Class Initialized
INFO - 2016-05-03 06:48:41 --> Helper loaded: date_helper
INFO - 2016-05-03 06:48:41 --> Helper loaded: form_helper
INFO - 2016-05-03 06:48:41 --> Form Validation Class Initialized
INFO - 2016-05-03 06:48:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:48:41 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:48:41 --> Final output sent to browser
DEBUG - 2016-05-03 06:48:41 --> Total execution time: 0.3062
INFO - 2016-05-03 06:48:52 --> Config Class Initialized
INFO - 2016-05-03 06:48:52 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:48:52 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:48:52 --> Utf8 Class Initialized
INFO - 2016-05-03 06:48:52 --> URI Class Initialized
INFO - 2016-05-03 06:48:52 --> Router Class Initialized
INFO - 2016-05-03 06:48:52 --> Output Class Initialized
INFO - 2016-05-03 06:48:52 --> Security Class Initialized
DEBUG - 2016-05-03 06:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:48:52 --> Input Class Initialized
INFO - 2016-05-03 06:48:52 --> Language Class Initialized
INFO - 2016-05-03 06:48:52 --> Loader Class Initialized
INFO - 2016-05-03 06:48:52 --> Helper loaded: url_helper
INFO - 2016-05-03 06:48:52 --> Database Driver Class Initialized
INFO - 2016-05-03 06:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:48:52 --> Controller Class Initialized
DEBUG - 2016-05-03 06:48:52 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:48:52 --> Email Class Initialized
INFO - 2016-05-03 06:48:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:48:52 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:48:52 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:48:52 --> Model Class Initialized
INFO - 2016-05-03 06:48:52 --> Helper loaded: date_helper
INFO - 2016-05-03 06:48:52 --> Helper loaded: form_helper
INFO - 2016-05-03 06:48:52 --> Form Validation Class Initialized
INFO - 2016-05-03 06:48:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:49:19 --> Config Class Initialized
INFO - 2016-05-03 06:49:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:49:19 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:49:19 --> Utf8 Class Initialized
INFO - 2016-05-03 06:49:19 --> URI Class Initialized
INFO - 2016-05-03 06:49:19 --> Router Class Initialized
INFO - 2016-05-03 06:49:19 --> Output Class Initialized
INFO - 2016-05-03 06:49:19 --> Security Class Initialized
DEBUG - 2016-05-03 06:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:49:19 --> Input Class Initialized
INFO - 2016-05-03 06:49:19 --> Language Class Initialized
INFO - 2016-05-03 06:49:19 --> Loader Class Initialized
INFO - 2016-05-03 06:49:19 --> Helper loaded: url_helper
INFO - 2016-05-03 06:49:19 --> Database Driver Class Initialized
INFO - 2016-05-03 06:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:49:19 --> Controller Class Initialized
DEBUG - 2016-05-03 06:49:19 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:49:19 --> Email Class Initialized
INFO - 2016-05-03 06:49:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:49:19 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:49:19 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:49:19 --> Model Class Initialized
INFO - 2016-05-03 06:49:19 --> Helper loaded: date_helper
INFO - 2016-05-03 06:49:19 --> Helper loaded: form_helper
INFO - 2016-05-03 06:49:19 --> Form Validation Class Initialized
INFO - 2016-05-03 06:49:19 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:49:20 --> Config Class Initialized
INFO - 2016-05-03 06:49:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 06:49:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:49:20 --> Utf8 Class Initialized
INFO - 2016-05-03 06:49:20 --> URI Class Initialized
DEBUG - 2016-05-03 06:49:20 --> No URI present. Default controller set.
INFO - 2016-05-03 06:49:20 --> Router Class Initialized
INFO - 2016-05-03 06:49:20 --> Output Class Initialized
INFO - 2016-05-03 06:49:20 --> Security Class Initialized
DEBUG - 2016-05-03 06:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:49:20 --> Input Class Initialized
INFO - 2016-05-03 06:49:20 --> Language Class Initialized
INFO - 2016-05-03 06:49:20 --> Loader Class Initialized
INFO - 2016-05-03 06:49:20 --> Helper loaded: url_helper
INFO - 2016-05-03 06:49:20 --> Database Driver Class Initialized
INFO - 2016-05-03 06:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:49:20 --> Controller Class Initialized
DEBUG - 2016-05-03 06:49:20 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:49:20 --> Email Class Initialized
INFO - 2016-05-03 06:49:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:49:20 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:49:20 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:49:20 --> Model Class Initialized
INFO - 2016-05-03 06:49:20 --> Helper loaded: date_helper
INFO - 2016-05-03 06:49:20 --> Helper loaded: form_helper
INFO - 2016-05-03 06:49:20 --> Form Validation Class Initialized
INFO - 2016-05-03 06:49:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:49:20 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:49:20 --> Final output sent to browser
DEBUG - 2016-05-03 06:49:20 --> Total execution time: 0.3592
INFO - 2016-05-03 06:50:52 --> Config Class Initialized
INFO - 2016-05-03 06:50:52 --> Hooks Class Initialized
INFO - 2016-05-03 06:50:52 --> Config Class Initialized
DEBUG - 2016-05-03 06:50:52 --> UTF-8 Support Enabled
INFO - 2016-05-03 06:50:52 --> Utf8 Class Initialized
INFO - 2016-05-03 06:50:52 --> Hooks Class Initialized
INFO - 2016-05-03 06:50:52 --> URI Class Initialized
DEBUG - 2016-05-03 06:50:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 06:50:52 --> No URI present. Default controller set.
INFO - 2016-05-03 06:50:52 --> Router Class Initialized
INFO - 2016-05-03 06:50:52 --> Utf8 Class Initialized
INFO - 2016-05-03 06:50:52 --> Output Class Initialized
INFO - 2016-05-03 06:50:52 --> Security Class Initialized
INFO - 2016-05-03 06:50:52 --> URI Class Initialized
DEBUG - 2016-05-03 06:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:50:52 --> Input Class Initialized
INFO - 2016-05-03 06:50:52 --> Router Class Initialized
INFO - 2016-05-03 06:50:52 --> Language Class Initialized
INFO - 2016-05-03 06:50:52 --> Output Class Initialized
INFO - 2016-05-03 06:50:52 --> Loader Class Initialized
INFO - 2016-05-03 06:50:52 --> Security Class Initialized
INFO - 2016-05-03 06:50:52 --> Helper loaded: url_helper
DEBUG - 2016-05-03 06:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 06:50:53 --> Input Class Initialized
INFO - 2016-05-03 06:50:53 --> Database Driver Class Initialized
INFO - 2016-05-03 06:50:53 --> Language Class Initialized
INFO - 2016-05-03 06:50:53 --> Loader Class Initialized
INFO - 2016-05-03 06:50:53 --> Helper loaded: url_helper
INFO - 2016-05-03 06:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:50:53 --> Controller Class Initialized
INFO - 2016-05-03 06:50:53 --> Database Driver Class Initialized
DEBUG - 2016-05-03 06:50:53 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:50:53 --> Email Class Initialized
INFO - 2016-05-03 06:50:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:50:53 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:50:53 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:50:53 --> Model Class Initialized
INFO - 2016-05-03 06:50:53 --> Helper loaded: date_helper
INFO - 2016-05-03 06:50:53 --> Helper loaded: form_helper
INFO - 2016-05-03 06:50:53 --> Form Validation Class Initialized
INFO - 2016-05-03 06:50:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:50:53 --> File loaded: C:\xampp\htdocs\optima\application\views\auth/login_page.php
INFO - 2016-05-03 06:50:53 --> Final output sent to browser
DEBUG - 2016-05-03 06:50:53 --> Total execution time: 0.4797
INFO - 2016-05-03 06:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 06:50:53 --> Controller Class Initialized
DEBUG - 2016-05-03 06:50:53 --> Config file loaded: C:\xampp\htdocs\optima\application\config/ion_auth.php
INFO - 2016-05-03 06:50:53 --> Email Class Initialized
INFO - 2016-05-03 06:50:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-03 06:50:53 --> Helper loaded: cookie_helper
INFO - 2016-05-03 06:50:53 --> Helper loaded: language_helper
DEBUG - 2016-05-03 06:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-03 06:50:53 --> Model Class Initialized
INFO - 2016-05-03 06:50:53 --> Helper loaded: date_helper
INFO - 2016-05-03 06:50:53 --> Helper loaded: form_helper
INFO - 2016-05-03 06:50:53 --> Form Validation Class Initialized
INFO - 2016-05-03 06:50:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-03 06:50:53 --> Final output sent to browser
DEBUG - 2016-05-03 06:50:53 --> Total execution time: 0.6739
